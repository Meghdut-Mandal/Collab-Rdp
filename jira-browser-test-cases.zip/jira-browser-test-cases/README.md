# Jira Browser Test Cases

### Run

```
mvn test
```