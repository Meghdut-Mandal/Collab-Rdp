/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.examples.seleniumtestdemo;

import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagement;
import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagementClientBuilder;
import com.amazonaws.services.simplesystemsmanagement.model.GetParameterRequest;


public class JiraCoreSecrets 
{
    private static JiraCoreSecrets jiraCoreSecrets;
    
    private JiraCoreSecrets() {}
    
    public static JiraCoreSecrets getInstance()
    {
        if (jiraCoreSecrets == null) {
            jiraCoreSecrets = new JiraCoreSecrets();
        }
        return jiraCoreSecrets;
    }
    
    public String getSecretyByParamName(String paramName) 
    {        
        final AWSSimpleSystemsManagement ssmClient = AWSSimpleSystemsManagementClientBuilder
                .standard()
                .withRegion("us-west-2")
                .build();

        GetParameterRequest request= new GetParameterRequest();
        request
                .withName(paramName)
                .setWithDecryption(true);

        return ssmClient.getParameter(request).getParameter().getValue();
    }
}
