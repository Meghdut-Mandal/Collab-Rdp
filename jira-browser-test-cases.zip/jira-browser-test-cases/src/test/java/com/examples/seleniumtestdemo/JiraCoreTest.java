package com.examples.seleniumtestdemo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 *
 * @author prasadve
 */
public class JiraCoreTest
{
    
    public WebDriver driver;
    
    public JiraCoreTest() {
        try {
            // System.setProperty("webdriver.chrome.driver","/usr/bin/chromedriver");
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--no-sandbox");
            options.addArguments("--disable-dev-shm-usage");
            driver = new ChromeDriver(options);
        } catch (Exception e) {
            e.printStackTrace();
            //TODO: handle exception
        }
    }
    
    @Test(priority = 0)
    @Parameters({"os_username"})
    public void Login(String os_username) 
    {    
        WebElement userElement;
        userElement = driver.findElement(By.name("os_username"));
        userElement.sendKeys(os_username);        
        
        WebElement passElement;
        passElement = driver.findElement(By.name("os_password"));
        //passElement.sendKeys("secret");
        passElement.sendKeys(JiraCoreSecrets.getInstance()
                .getSecretyByParamName("/jira/secrets/"+os_username));
        
        WebElement secureLoginElement;
        secureLoginElement = driver.findElement(By.name("login"));
        secureLoginElement.submit();
    }
    
    @Test(priority = 5)
    public void Manage_Dashboards()
    {
        // Click on "Dashboards" (drop-down)
        WebElement dashboardsLink = driver.findElement(By.id("home_link"));
        dashboardsLink.click();

        // Click on "Manage Dashboards" (menu item)
        WebElement manageDashboardsLink = driver.findElement(By.id("manage_dash_link_lnk"));
        manageDashboardsLink.click();

        // Verify page loaded by checking for "Create new dashboard" button
        WebElement addGadget = driver.findElement(By.id("create_page"));
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOf(addGadget));
    }

    @Test(priority = 10)
    public void List_Projects() 
    {
        /*
        WebElement addGadget = driver.findElement(By.id("add-gadget"));
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOf(addGadget));
        */
        
        WebElement browseLink = driver.findElement(By.id("browse_link"));
        browseLink.click();                                
        
        WebElement viewAllProjectsLink = driver.findElement(By.id("project_view_all_link_lnk"));
        viewAllProjectsLink.click();
    }
    
    
    @Test(priority = 20)
    @Parameters({"os_project"})
    public void Browse_Project(String os_project) 
    {
        WebElement projectsView = driver.findElement(By.id("project-filter-text"));
        WebDriverWait projectsViewWait = new WebDriverWait(driver, 60);
        projectsViewWait.until(ExpectedConditions.visibilityOf(projectsView));
        projectsView.sendKeys(os_project);
        
        WebElement projectLink = driver.findElement(By.xpath("//a[contains(text(),'"+os_project+"')]"));
        projectLink.click();                        
    }

    @Test(priority = 30)
    public void Current_Search() 
    {
        WebElement projectView = driver.findElement(By.xpath("//span[@title='Issues']"));
        WebDriverWait projectViewWait = new WebDriverWait(driver, 60);
        projectViewWait.until(ExpectedConditions.visibilityOf(projectView));
        
        WebElement findLink = driver.findElement(By.id("find_link"));
        findLink.click();                
        
        WebElement searchLink = driver.findElement(By.id("jira.top.navigation.bar:issues_drop_current_lnk"));
        searchLink.click();
    }
    
    
    @Test(priority = 40)
    public void Search_All_Issues() 
    {
        WebElement viewIssues = driver.findElement(By.id("key-val"));
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.elementToBeClickable(viewIssues));
        
        WebElement allIssues = driver.findElement(By.linkText("All issues"));
        allIssues.click();
    }
    
    @Test(priority = 50)
    public void Search_Open_Issues() 
    {
        WebElement viewIssues = driver.findElement(By.id("key-val"));
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.elementToBeClickable(viewIssues));
        
        WebElement openIssues = driver.findElement(By.linkText("Open issues"));
        openIssues.click();
    }
    
    @Test(priority = 60)
    public void Search_Completed_Issues()
    {
        WebElement viewIssues = driver.findElement(By.id("key-val"));
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.elementToBeClickable(viewIssues));
        
        WebElement openIssues = driver.findElement(By.linkText("Done issues"));
        openIssues.click();
    }
    
    @Test(priority = 70)
    public void Create_Issue() 
    {
        WebElement viewIssues = driver.findElement(By.id("key-val"));
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.elementToBeClickable(viewIssues));
        
        WebElement createLink = driver.findElement(By.id("create_link"));
        createLink.click();
        
        WebElement summaryIssue = driver.findElement(By.id("summary"));
        WebDriverWait wait1 = new WebDriverWait(driver, 60);
        wait1.until(ExpectedConditions.visibilityOf(summaryIssue));        
        summaryIssue.click();
        summaryIssue.sendKeys("New Issue from Selenium - "+ new Date());
        
        WebElement submitIssue = driver.findElement(By.id("create-issue-submit"));      
        submitIssue.click();
    }
    
    
    @Test(priority = 80)
    public void Edit_Issue() 
    {
        WebElement createIssue = driver.findElement(By.xpath("//a[@class='issue-created-key issue-link']"));
        WebDriverWait wait0 = new WebDriverWait(driver, 60);
        wait0.until(ExpectedConditions.elementToBeClickable(createIssue));
        createIssue.click();        
        
        WebElement editIssue = driver.findElement(By.id("edit-issue"));
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOf(editIssue));        
        editIssue.click();
        
        WebElement editorIssue = driver.findElement(By.id("summary"));
        WebDriverWait wait2 = new WebDriverWait(driver, 60);
        wait2.until(ExpectedConditions.visibilityOf(editorIssue));        
        editorIssue.click();
        editorIssue.sendKeys(" **EDIT** ");
        
        WebElement submitIssue = driver.findElement(By.id("edit-issue-submit"));
        WebDriverWait wait3 = new WebDriverWait(driver, 60);
        wait3.until(ExpectedConditions.visibilityOf(submitIssue));        
        submitIssue.click();
        
        WebDriverWait wait4 = new WebDriverWait(driver, 60);
        wait4.until(ExpectedConditions.visibilityOf(editIssue));
    }
    
        
    /*@Test(priority = 90)
    public void j_Comment_Issue() 
    {
        WebElement commentIssue = driver.findElement(By.id("footer-comment-button"));
        WebDriverWait wait1 = new WebDriverWait(driver, 60);
        wait1.until(ExpectedConditions.elementToBeClickable(commentIssue));
        commentIssue.click();            
        
        WebElement visualComment = driver.findElement(By.id("comment"));
        WebDriverWait wait2 = new WebDriverWait(driver, 60);
        wait2.until(ExpectedConditions.visibilityOf(visualComment));
        visualComment.click();
        visualComment.sendKeys("New Issue Comment from Selenium - "+ new Date());
        
        WebElement addComment = driver.findElement(By.xpath("//input[@id='issue-comment-add-submit']"));
        WebDriverWait wait3 = new WebDriverWait(driver, 60);
        wait3.until(ExpectedConditions.elementToBeClickable(addComment));
        addComment.click();
        
        WebElement msgContainer = driver.findElement(By.xpath("//p[contains(text(),'New Issue Comment from Selenium')]"));        
        WebDriverWait wait6 = new WebDriverWait(driver, 60);
        wait6.until(ExpectedConditions.visibilityOf(msgContainer));
    }*/
    
    @Test(priority = 100)
    public void Transition_Issue_In_Progress() 
    {
        WebElement startIssue = driver.findElement(By.xpath("//span[contains(text(),'In Progress')]"));
        WebDriverWait wait10 = new WebDriverWait(driver, 60);
        wait10.until(ExpectedConditions.elementToBeClickable(startIssue));
        startIssue.click();
    }
    
    @Test(priority = 110)
    public void Transition_Issue_Done() 
    {                
        WebElement doneIssue = driver.findElement(By.xpath("//span[contains(text(),'Done')]"));
        WebDriverWait wait11 = new WebDriverWait(driver, 60);
        wait11.until(ExpectedConditions.elementToBeClickable(doneIssue));
        
        Actions actions = new Actions(driver);
        actions.moveToElement(doneIssue).click().perform();
        //doneIssue.click();
    }

    @Test(priority = 120)
    public void Logout()
    {
        // WebElement editIssue = driver.findElement(By.xpath("//span[contains(text(),'Edit')]"));
        // WebDriverWait wait = new WebDriverWait(driver, 60);
        // wait.until(ExpectedConditions.elementToBeClickable(editIssue));
        
        try {
        Thread.sleep(10000);
        WebElement userOptionsLink = driver.findElement(By.id("user-options"));
        userOptionsLink.click();                
        
        WebElement logoutLink = driver.findElement(By.id("log_out"));
        logoutLink.click();
                
        WebElement loginLinkText = driver.findElement(By.xpath("//strong[contains(text(),'You are logged out now')]"));
        WebDriverWait waitLoginLinkText = new WebDriverWait(driver, 60);
        waitLoginLinkText.until(ExpectedConditions.visibilityOf(loginLinkText));
        }catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    @BeforeClass
    @Parameters({"os_jira_url", "os_browser_type", "os_browser_path"})
    public void beforeClass(String os_jira_url, String os_browser_type, String os_browser_path)
    {
        System.setProperty(os_browser_type, os_browser_path);        
        driver = new ChromeDriver();
        driver.navigate().to(os_jira_url);
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }
    
    @AfterClass
    public void afterClass() throws InterruptedException
    {
        driver.quit();
    }
    
    @BeforeMethod
    public void sleep1()
    {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            System.err.println(ex);
        }
    }
    
    @AfterMethod
    public void sleep2()
    {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            System.err.println(ex);
        }
    }
}
